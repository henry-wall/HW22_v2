import { useState } from "react";
import type { TournamentConfig, TournamentEvent } from "../../types/tournament";
import { ThemeToggle } from "../shared/ThemeToggle";
import logoUrl from "../../assets/WallBT_Full.png";
import { exportDataAsJSON, importDataFromJSON } from "../../utils/backupUtils";
import { useStorage } from "../../services/storage/StorageContext";

interface HomeScreenProps {
  tournaments: TournamentConfig[];
  events: TournamentEvent[];
  onNewTournament: () => void;
  onOpenTournament: (id: string) => void;
  onEditTournament: (id: string, partial: Partial<TournamentConfig>) => void;
  onCreateEvent: (name: string) => TournamentEvent;
  onDeleteEvent: (eventId: string) => void;
  onLinkTournament: (tournamentId: string, eventId: string | undefined) => void;
}

const formatLabels: Record<string, string> = {
  super8: "Super 8",
  kingqueen: "King & Queen",
  mixeddoubles: "Troca de Casais",
  fixeddoubles: "Duplas Fixas",
  drawdoubles: "Duplas Sorteadas",
};

const formatIcons: Record<string, string> = {
  super8: "8️⃣",
  kingqueen: "👑",
  mixeddoubles: "💑",
  fixeddoubles: "👥",
  drawdoubles: "🎲",
};

const categoryLabels: Record<string, string> = {
  masc: "Masc",
  fem: "Fem",
  mixed: "Misto",
};

const categoryColors: Record<string, string> = {
  masc: "rgba(6, 182, 212, 0.15)",
  fem: "rgba(236, 72, 153, 0.15)",
  mixed: "rgba(245, 158, 11, 0.15)",
};

const categoryBorders: Record<string, string> = {
  masc: "rgba(6, 182, 212, 0.3)",
  fem: "rgba(236, 72, 153, 0.3)",
  mixed: "rgba(245, 158, 11, 0.3)",
};

const categoryText: Record<string, string> = {
  masc: "#06B6D4",
  fem: "#EC4899",
  mixed: "#F59E0B",
};

export default function HomeScreen({
  tournaments,
  events,
  onNewTournament,
  onOpenTournament,
  onEditTournament,
  onCreateEvent,
  onDeleteEvent,
  onLinkTournament,
}: HomeScreenProps) {
  const { mode, setMode, migrateLocalToCloud } = useStorage();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [tempName, setTempName] = useState("");

  // Event creation state
  const [showCreateEvent, setShowCreateEvent] = useState(false);
  const [newEventName, setNewEventName] = useState("");

  // Linking modal state
  const [linkingTournamentId, setLinkingTournamentId] = useState<string | null>(null);

  // Delete confirmation state
  const [deletingEventId, setDeletingEventId] = useState<string | null>(null);

  const handleStartEdit = (e: React.MouseEvent, t: TournamentConfig) => {
    e.stopPropagation();
    setEditingId(t.id);
    setTempName(t.name);
  };

  const handleSaveEdit = () => {
    if (editingId && tempName.trim()) {
      onEditTournament(editingId, { name: tempName.trim() });
    }
    setEditingId(null);
  };

  const handleCreateEvent = () => {
    if (!newEventName.trim()) return;
    onCreateEvent(newEventName);
    setNewEventName("");
    setShowCreateEvent(false);
  };

  // Group tournaments: by event, then standalone
  const standaloneTournaments = tournaments.filter(t => !t.eventId);

  const tournamentsByEvent: Record<string, TournamentConfig[]> = {};
  events.forEach(ev => {
    tournamentsByEvent[ev.id] = tournaments.filter(t => t.eventId === ev.id);
  });

  const renderTournamentCard = (t: TournamentConfig, compact = false) => (
    <div
      key={t.id}
      onClick={() => onOpenTournament(t.id)}
      className={`w-full text-left surface-card hover:border-brand-pink/50 transition-all duration-200 group border-border-main cursor-pointer ${compact ? "p-3" : ""}`}
      style={{ borderLeft: `4px solid ${categoryText[t.category] || "transparent"}` }}
    >
      <div className="flex items-center gap-3">
        <div
          className={`${compact ? "w-9 h-9 text-lg" : "w-12 h-12 text-2xl"} rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-200 group-hover:scale-110 border`}
          style={{ 
            background: categoryColors[t.category] || "rgba(255,5,149,0.1)",
            borderColor: categoryBorders[t.category] || "transparent"
          }}
        >
          {formatIcons[t.format] || "🎾"}
        </div>
        <div className="flex-1 min-w-0">
          {editingId === t.id ? (
            <div onClick={e => e.stopPropagation()}>
              <input
                type="text"
                value={tempName}
                onChange={e => setTempName(e.target.value)}
                onBlur={handleSaveEdit}
                onKeyDown={e => e.key === "Enter" && handleSaveEdit()}
                autoFocus
                className="bg-page border-2 border-brand-pink rounded-lg px-2 py-1 text-primary font-bold w-full outline-none"
              />
            </div>
          ) : (
            <div className="flex items-center gap-2 group/name">
              <div className={`font-bold text-primary truncate ${compact ? "text-sm" : "text-base"}`}>{t.name}</div>
              <button
                onClick={(e) => handleStartEdit(e, t)}
                className="opacity-0 group-hover/name:opacity-100 p-1 text-muted hover:text-brand-pink transition-all"
              >
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                </svg>
              </button>
            </div>
          )}
          <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
            <span className="badge-pink text-[10px] px-2 py-0.5">{formatLabels[t.format]}</span>
            <span className="text-[10px] text-muted/70 font-medium">{categoryLabels[t.category] || t.category}</span>
            <span className="text-[10px] text-muted/50">{t.numPlayers} {t.format === "mixeddoubles" ? "casais" : "jog."}</span>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {/* Link button */}
          <button
            onClick={(e) => { e.stopPropagation(); setLinkingTournamentId(t.id); }}
            className="opacity-0 group-hover:opacity-100 p-1.5 rounded-lg text-muted hover:text-brand-cyan hover:bg-brand-cyan/10 transition-all"
            title="Vincular a um Evento"
          >
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
            </svg>
          </button>
          <svg className="w-4 h-4 text-muted group-hover:text-brand-pink transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-dvh flex flex-col transition-colors duration-300">
      {/* Hero Header */}
      <div className="relative px-5 pt-8 pb-6 overflow-hidden">
        <div className="absolute top-4 right-5 z-20 flex items-center gap-2">
          {/* Storage Toggle */}
          <div className="flex bg-black/40 p-1 rounded-xl border border-white/10 mr-2">
            <button 
              onClick={() => setMode("local")}
              className={`px-2 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter transition-all ${mode === "local" ? "bg-white/10 text-white shadow-sm" : "text-white/30 hover:text-white/50"}`}
            >
              Local
            </button>
            <button 
              onClick={() => setMode("cloud")}
              className={`px-2 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter transition-all flex items-center gap-1 ${mode === "cloud" ? "bg-brand-cyan/20 text-brand-cyan shadow-sm" : "text-white/30 hover:text-white/50"}`}
            >
              {mode === "cloud" && <span className="w-1 h-1 rounded-full bg-brand-cyan animate-pulse"></span>}
              Nuvem
            </button>
          </div>

          <button 
            onClick={migrateLocalToCloud}
            className="w-8 h-8 rounded-lg bg-brand-cyan/10 text-brand-cyan flex items-center justify-center hover:bg-brand-cyan/20 transition-all border border-brand-cyan/20"
            title="Sincronizar dados locais para a nuvem"
          >
            ☁️
          </button>
          <button 
            onClick={exportDataAsJSON}
            className="w-8 h-8 rounded-lg bg-brand-cyan/10 text-brand-cyan flex items-center justify-center hover:bg-brand-cyan/20 transition-all border border-brand-cyan/20"
            title="Exportar Backup (JSON)"
          >
            💾
          </button>
          <label className="w-8 h-8 rounded-lg bg-brand-pink/10 text-brand-pink flex items-center justify-center hover:bg-brand-pink/20 transition-all border border-brand-pink/20 cursor-pointer" title="Importar Backup (JSON)">
            📂
            <input 
              type="file" 
              className="hidden" 
              accept=".json"
              onChange={async (e) => {
                const file = e.target.files?.[0];
                if (file) {
                  const ok = await importDataFromJSON(file);
                  if (ok) window.location.reload();
                  else alert("Erro ao importar backup.");
                }
              }}
            />
          </label>
          <ThemeToggle />
        </div>
        <div className="absolute inset-0 pointer-events-none" style={{
          background: "radial-gradient(ellipse at top center, rgba(255,5,149,0.12) 0%, transparent 70%)",
        }} />
        <div className="flex flex-col items-center mb-6">
          <img
            src={logoUrl}
            alt="Wall Beach Tennis"
            className="h-28 object-contain mb-4"
            style={{ filter: "drop-shadow(0 0 16px rgba(255,5,149,0.5))" }}
          />
          <div className="flex items-center gap-2">
            <div className="h-px flex-1 w-8" style={{ background: "linear-gradient(to right, transparent, rgba(255,5,149,0.4))" }} />
            <span className="text-xs font-bold tracking-widest text-gray-400 uppercase">Tournament Manager</span>
            <div className="h-px flex-1 w-8" style={{ background: "linear-gradient(to left, transparent, rgba(255,5,149,0.4))" }} />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2">
          <button onClick={onNewTournament} className="btn-primary relative overflow-hidden">
            <span className="text-xl">+</span>
            <span>Novo Torneio</span>
          </button>
          <button
            onClick={() => setShowCreateEvent(true)}
            className="btn-secondary flex items-center justify-center gap-2 py-3"
          >
            <span className="text-base">🗂️</span>
            <span className="text-sm font-bold">Criar Evento</span>
          </button>
        </div>
      </div>

      {/* Quick Stats */}
      {tournaments.length > 0 && (
        <div className="grid grid-cols-3 gap-3 px-5 mb-6">
          {[
            { label: "Eventos", value: events.length, icon: "🗂️" },
            { label: "Torneios", value: tournaments.length, icon: "🏆" },
            { label: "Avulsos", value: standaloneTournaments.length, icon: "🎾" },
          ].map(s => (
            <div key={s.label} className="surface-card text-center">
              <div className="text-xl mb-1">{s.icon}</div>
              <div className="text-2xl font-black text-primary">{s.value}</div>
              <div className="text-xs text-muted">{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 px-5 pb-8 space-y-6">
        {/* No content */}
        {tournaments.length === 0 && events.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl mb-4"
              style={{ background: "rgba(255,5,149,0.1)", border: "1px dashed rgba(255,5,149,0.3)" }}>
              🎾
            </div>
            <h3 className="text-lg font-bold text-primary mb-2">Nenhum torneio criado</h3>
            <p className="text-muted text-sm max-w-xs">
              Toque em <strong className="text-primary">Novo Torneio</strong> para começar, ou crie um <strong className="text-primary">Evento</strong> para agrupar múltiplas categorias.
            </p>
          </div>
        )}

        {/* Events Section */}
        {events.map(ev => {
          const evTournaments = tournamentsByEvent[ev.id] || [];
          return (
            <div key={ev.id} className="surface-card border-border-main overflow-hidden">
              {/* Event Header */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-lg">🗂️</span>
                  <div>
                    <h2 className="font-black text-primary text-base leading-tight">{ev.name}</h2>
                    <span className="text-xs text-muted">{evTournaments.length} categoria{evTournaments.length !== 1 ? "s" : ""}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setDeletingEventId(ev.id)}
                    className="p-1.5 rounded-lg text-muted hover:text-red-500 hover:bg-red-500/10 transition-all"
                    title="Excluir Evento"
                  >
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
              </div>

              {/* Divider */}
              <div className="h-px bg-border-main mb-3" />

              {/* Tournaments in this event */}
              {evTournaments.length === 0 ? (
                <div className="text-center py-4 text-muted text-sm italic">
                  Nenhum torneio vinculado ainda.<br />
                  <span className="text-xs">Use o ícone 🔗 em um torneio para adicioná-lo aqui.</span>
                </div>
              ) : (
                <div className="space-y-2">
                  {evTournaments.map(t => renderTournamentCard(t, true))}
                </div>
              )}
            </div>
          );
        })}

        {/* Standalone Tournaments */}
        {standaloneTournaments.length > 0 && (
          <div>
            <h2 className="text-sm font-bold text-muted uppercase tracking-widest mb-3">
              {events.length > 0 ? "Torneios Avulsos" : "Meus Torneios"}
            </h2>
            <div className="space-y-3">
              {[...standaloneTournaments].reverse().map(t => renderTournamentCard(t))}
            </div>
          </div>
        )}
      </div>

      {/* Create Event Modal */}
      {showCreateEvent && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="surface-card w-full max-w-md animate-slide-up">
            <h3 className="text-lg font-black text-primary mb-1">Criar Evento</h3>
            <p className="text-sm text-muted mb-4">Agrupe múltiplas categorias sob um evento (ex: "Copa Verão 2024").</p>
            <input
              type="text"
              className="input-dark mb-4"
              placeholder="Nome do Evento (ex: Copa Verão 2024)"
              value={newEventName}
              onChange={e => setNewEventName(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleCreateEvent()}
              autoFocus
            />
            <div className="flex gap-2">
              <button onClick={() => { setShowCreateEvent(false); setNewEventName(""); }} className="btn-secondary py-2 text-sm">
                Cancelar
              </button>
              <button
                onClick={handleCreateEvent}
                className="btn-primary py-2 text-sm"
                disabled={!newEventName.trim()}
              >
                Criar Evento
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Link Tournament to Event Modal */}
      {linkingTournamentId && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="surface-card w-full max-w-md animate-slide-up">
            {(() => {
              const t = tournaments.find(t => t.id === linkingTournamentId)!;
              return (
                <>
                  <h3 className="text-lg font-black text-primary mb-1">Vincular ao Evento</h3>
                  <p className="text-sm text-muted mb-4">
                    Selecione um evento para <strong className="text-primary">{t?.name}</strong>:
                  </p>
                  <div className="space-y-2 mb-4 max-h-48 overflow-y-auto">
                    {/* Unlink option */}
                    {t?.eventId && (
                      <button
                        onClick={() => { onLinkTournament(linkingTournamentId, undefined); setLinkingTournamentId(null); }}
                        className="w-full text-left p-3 rounded-xl border-2 border-red-500/20 bg-red-500/5 hover:bg-red-500/10 transition-all flex items-center gap-3"
                      >
                        <span className="text-lg">🔗</span>
                        <span className="font-bold text-red-400 text-sm">Desvincular do evento atual</span>
                      </button>
                    )}
                    {events.length === 0 ? (
                      <p className="text-muted text-sm text-center py-4">Nenhum evento criado ainda.</p>
                    ) : (
                      events.map(ev => (
                        <button
                          key={ev.id}
                          onClick={() => { onLinkTournament(linkingTournamentId, ev.id); setLinkingTournamentId(null); }}
                          className={`w-full text-left p-3 rounded-xl border-2 transition-all flex items-center gap-3 ${
                            t?.eventId === ev.id
                              ? "border-brand-pink bg-brand-pink/10"
                              : "border-border-main hover:border-brand-pink/50 bg-surface"
                          }`}
                        >
                          <span className="text-lg">🗂️</span>
                          <div>
                            <div className="font-bold text-primary text-sm">{ev.name}</div>
                            <div className="text-xs text-muted">{(tournamentsByEvent[ev.id] || []).length} torneio(s)</div>
                          </div>
                          {t?.eventId === ev.id && <span className="ml-auto text-brand-pink text-xs font-black">✓ atual</span>}
                        </button>
                      ))
                    )}
                  </div>
                  <button onClick={() => setLinkingTournamentId(null)} className="btn-secondary py-2 text-sm w-full">
                    Fechar
                  </button>
                </>
              );
            })()}
          </div>
        </div>
      )}

      {/* Delete Event Confirmation */}
      {deletingEventId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="surface-card w-full max-w-sm animate-slide-up text-center">
            <div className="text-4xl mb-3">⚠️</div>
            <h3 className="text-lg font-black text-primary mb-1">Excluir Evento?</h3>
            <p className="text-sm text-muted mb-6">
              Os torneios vinculados <strong className="text-primary">não serão excluídos</strong>, apenas desvinculados do evento.
            </p>
            <div className="flex gap-2">
              <button onClick={() => setDeletingEventId(null)} className="btn-secondary py-2 text-sm">
                Cancelar
              </button>
              <button
                onClick={() => { onDeleteEvent(deletingEventId); setDeletingEventId(null); }}
                className="flex-1 py-2 rounded-2xl font-bold text-sm text-white bg-red-500 hover:bg-red-600 transition-colors"
              >
                Excluir Evento
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
