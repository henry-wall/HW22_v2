import type { EngineMatch } from "../engines/super8Engine";
import { useTournamentState } from "./useTournamentState";

export interface MatchResult {
  scoreA: number | string;
  scoreB: number | string;
}

// KingQueen uses a more complex structure, but we can unify the base
export interface TournamentData {
  status: "planning" | "operation" | "finished";
  matches: EngineMatch[]; // For Super8 and Mixed
  matchResults: Record<string, MatchResult>;
  inProgressMatches: Record<number, EngineMatch>;
  completedMatches: EngineMatch[];
  matchQueue: EngineMatch[];
  groupRounds?: any[];
  seriesRounds?: any[];
  seriesPlayerOrder?: number[][];
  liveScores?: Record<string, any>; // Stores live ScoreState from RefereeScoreboard
  players?: string[];
  couples?: { manName: string; womanName: string }[];
}

const DEFAULT_DATA: TournamentData = {
  status: "planning",
  matches: [],
  matchResults: {},
  inProgressMatches: {},
  completedMatches: [],
  matchQueue: [],
  liveScores: {},
  players: [],
  couples: [],
};

export function useTournamentData(tournamentId: string) {
  return useTournamentState<TournamentData>(`wallbt_v2_tournament_${tournamentId}`, DEFAULT_DATA);
}
